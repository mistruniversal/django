rightCounter = 0
questionsCounter = 0
questions = ["сколько цветов у радуги?", "какой язык мы изучаем?"]
rightAnswer = ["7", "Pytho"]

while questionsCounter < len(questions):
    answer = input(questions[questionsCounter])
    if answer.lower() == rightAnswer[questionsCounter]:
        rightCounter += 1
questionsCounter += 1

print(f"вы набрали баллов:{rightCounter}")