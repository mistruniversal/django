from random import randint
gr = int(input('4,6,8,12,20'))
print(randint(1,gr))