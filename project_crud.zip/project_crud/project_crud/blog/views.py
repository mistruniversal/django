from django.shortcuts import render,redirect
from .forms import Forms

def add(request):
    if request.method == "POST":
        form=Forms(request.POST)
        if form.is_valid():
            form.save()
            return redirect()