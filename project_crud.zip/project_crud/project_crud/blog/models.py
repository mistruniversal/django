from django.db import models


# class Person(models.Model):
#     name = models.CharField(max_length = 50)
#     age = models.IntegerField()


class Category(models.Model):
    name = models.CharField(max_length=50)
class Person(models.Model):
    name = models.CharField(max_length=50)
    description = models.TextField(max_length=255, blank=True, default='')


class Article(models.Model):
    title = models.CharField(max_length=200)
    date = models.DateTimeField()
    content = models.TextField()
    status = models.IntegerField()

class TestForm(models.Model):
    title=models.CharField(max_length=100)
    autor=models.CharField(max_length=100)
    publosher_date=models.DateField()


