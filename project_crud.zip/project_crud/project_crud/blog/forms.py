from django import forms
from .models import TestForm


class Forms(forms.ModelForm):
    class Meta:
        model=TestForm
        field=['title','autor','publosher_date']