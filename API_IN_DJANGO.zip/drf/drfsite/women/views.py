from rest_framework import generics
from .models import Women,Category,ModelOdin
from .serializers import WomenSerializer,Categoruserialize,Modelkaodna

class WomenAPIView(generics.ListAPIView):
    queryset = Women.objects.all()
    serializer_class = WomenSerializer
class CategoryAPIView(generics.ListAPIView):
    queryset = Category.objects.all()
    serializer_class = Categoruserialize

class ModelOdinAPIView(generics.ListAPIView):
    queryset = ModelOdin.objects.all()
    serializer_class = Modelkaodna
