from rest_framework import serializers
from .models import Women,Category,ModelOdin


class WomenSerializer(serializers.ModelSerializer):

    class Meta:
        model = Women
        fields = ('__all__')


class Categoruserialize(serializers.ModelSerializer):
    class Meta:
        model=Category
        fields = ('name')
class Modelkaodna(serializers.ModelSerializer):
    class Meta:
        model = ModelOdin
        fields = ('__all__')