from flask import Flask,request
from flask import render_template
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate

app = Flask(import_name='name')


app.config['SQLALCHEMY_DATABASE_URI']='sqlite:////absolute/path/to/app.db'

app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False

db=SQLAlchemy(app)

migrate=Migrate(app,db)
class User(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    username=db.Column(db.String(80),unique=True,nullnamber=False)
    def __repr__(self):
        return f'User {self.username}'

@app.route('/')
def hello():
    return render_template('index.html')


# @app.route('/user/<username>')
# def calluser(username):
#     return f'hello world {username}'
#
#
# @app.route('/about')
# def calr():
#     return render_template('index.html',template_name_or_list=[1,2,3,4])
#
# @app.route('/hello')
# def calrs():
#     data={'name':'мя'}
#     return render_template('index.html',**data)


@app.route('/sub',methods=['POST'])
def ca():
    name=request.form['name']
    return f'Submit = {name}'

if __name__ == '__main__':
    app.run(debug=True)
